/**
 * Clase que representa a un animal del zoológico
 * @author Estrada García Luis Gerardo
 * @author Jiménez Hernández Allan  
 * @author Mancera Quiroz Javier Alejandro
 * @author Mora Hernández Dulce Julieta
 * @author Peña Nuñez Axel Yael
 * @version 10/09/2023
 */

public class Animal {
    private String nombre;
    private String especie;
    private String peso;
    private String altura;
    private String sexo;
    private String numJaula;
    private String alimentacion;
    private String animalId;

    /**
     * Metodo constructor de la clase
     * @param nombre El nombre del animal
     * @param especie La especie del animal
     * @param peso El peso del animal
     * @param altura La altura del animal
     * @param sexo El sexo del animal
     * @param numJaula El numero de jaula del animal
     * @param alimentacion La alimentacion del animal
     * @param animalId El identificador del animal
     */
    public Animal(String nombre, String especie, String peso, String altura, String sexo, String numJaula, String alimentacion, String animalId) {
        this.nombre = nombre;
        this.especie = especie;
        this.peso = peso;
        this.altura = altura;
        this.sexo = sexo;
        this.numJaula = numJaula;
        this.alimentacion = alimentacion;
        this.animalId = animalId;
    }

    /**
     * Metodo toString de la clase
     * @return Una cadena que representa la información del animal.
     */
    @Override
    public String toString() {
        return this.nombre + "," + this.especie + "," + this.peso + "," + this.altura + "," + this.sexo + '\'' +
                "," + this.numJaula + "," + this.alimentacion + "," + this.animalId;
    }

    /**
     * Metodo que devuelve el nombre del animal
     * @return El nombre del animal
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Metodo que modifica el nombre del animal
     * @param nombre El nombre del animal a modificar
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Metodo que devuelve la especie del animal
     * @return La especie del animal
     */
    public String getEspecie() {
        return especie;
    }

    /**
     * Metodo que modifica la especie del animal
     * @param especie La especie del animal a modificar
     */
    public void setEspecie(String especie) {
        this.especie = especie;
    }

    /**
     * Metodo que devuelve el peso del animal
     * @return El peso del animal
     */
    public String getPeso() {
        return peso;
    }

    /**
     * Metodo que modifica el peso del animal
     * @param peso El peso del animal a modificar
     */
    public void setPeso(String peso) {
        this.peso = peso;
    }

    /**
     * Metodo que devuelve la altura del animal
     * @return La altura del animal
     */
    public String getAltura() {
        return altura;
    }

    /**
     * Metodo que modifica la altura del animal
     * @param altura La altura del animal a modificar
     */
    public void setAltura(String altura) {
        this.altura = altura;
    }

    /**
     * Metodo que devuelve el sexo del animal
     * @return El sexo del animal
     */
    public String getSexo() {
        return sexo;
    }

    /**
     * Metodo que modifica el sexo del animal
     * @param sexo El sexo del animal a modificar
     */
    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    /**
     * Metodo que devuelve el numero de jaula del animal
     * @return El numero de jaula del animal
     */
    public String getNumJaula() {
        return numJaula;
    }

    /**
     * Metodo que modifica el numero de jaula del animal
     * @param numJaula El numero de jaula del animal a modificar
     */
    public void setNumJaula(String numJaula) {
        this.numJaula = numJaula;
    }

    /**
     * Metodo que devuelve la alimentacion del animal
     * @return La alimentacion del animal
     */
    public String getAlimentacion() {
        return alimentacion;
    }

    /**
     * Metodo que modifica la alimentacion del animal
     * @param alimentacion La alimentacion del animal a modificar
     */
    public void setAlimentacion(String alimentacion) {
        this.alimentacion = alimentacion;
    }

    /**
     * Metodo que devuelve el identificador del animal
     * @return El identificador del animal
     */
    public String getAnimaId() {
        return animalId;
    }

    /**
     * Metodo que modifica el identificador del animal
     * @param animalId El identificador del animal a modificar
     */
    public void setAnimaId(String animalId) {
        this.animalId = animalId;
    }
}
