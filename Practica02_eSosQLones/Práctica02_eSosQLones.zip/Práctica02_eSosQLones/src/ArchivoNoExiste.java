public class ArchivoNoExiste extends Exception {
    public ArchivoNoExiste(String message){
        super(message);
    }

}
