/**
 * Clase que representa a un veterinario del zoológico
 * @author Estrada García Luis Gerardo
 * @author Jiménez Hernández Allan  
 * @author Mancera Quiroz Javier Alejandro
 * @author Mora Hernández Dulce Julieta
 * @author Peña Nuñez Axel Yael
 * @version 10/09/2023
 */

public class Veterinario{
    private String rfc;
    private String nombre;
    private String apellidoPat;
    private String apellidoMat;
    private String calle;
    private String numInt;
    private String numExt;
    private String colonia;
    private String estado;
    private String telefono;
    private String fechaInicio;
    private String fechaNac;
    private String correo;
    private String genero;
    private String especialidad;
    private String salario;


    /**
     * Constructor de la clase Veterinario
     * @param rfc El rfc del veterinario
     * @param nombre El nombre del veterianrio
     * @param apellidoPat El apellido paterno del veterinario
     * @param apellidoMat El apellido materno del veterinario
     * @param calle La calle de la direccion del veterinario
     * @param numInt El numero interior de la direccion del veterinario
     * @param numExt El numero exterior de la direccion del veterinario
     * @param colonia La colonia de la direccion del veterinario
     * @param estado El estado de la direccion del veterinario
     * @param telefono El telefono del veterinario
     * @param fechaInicio Fecha en la que comenzo a trabajar el veterinario
     * @param fechaNac Fecha de nacimiento del veterinario
     * @param correo Correo del veterinario
     * @param genero Genero del veterinario
     * @param especialidad Especialidad del veterinario
     * @param salario Salario del veterinario
     */

    public Veterinario(String rfc, String nombre, String apellidoPat, String apellidoMat, String calle, String numInt, String numExt, String colonia, String estado, String telefono, String fechaInicio, String fechaNac, String correo, String genero, String especialidad, String salario) {
        this.rfc = rfc;
        this.nombre = nombre;
        this.apellidoPat = apellidoPat;
        this.apellidoMat = apellidoMat;
        this.calle = calle;
        this.numInt = numInt;
        this.numExt = numExt;
        this.colonia = colonia;
        this.estado = estado;
        this.telefono = telefono;
        this.fechaInicio = fechaInicio;
        this.fechaNac = fechaNac;
        this.correo = correo;
        this.genero = genero;
        this.especialidad = especialidad;
        this.salario = salario;
    }
    
    /**
     * Metodo toString de la clase
     * @return Una cadena que representa la información del veterinario.
     */
    @Override
    public String toString() {
        return this.rfc + "," + this.nombre + "," + this.apellidoPat + "," + this.apellidoMat + "," + 
        this.calle + "," + this.numInt + "," + this.numExt + "," + this.colonia + "," + this.estado 
        + "," + this.telefono + "," + this.fechaInicio +  "," + this.fechaNac 
        + "," + this.correo + "," + this.genero + "," + this.especialidad + "," + this.salario;
    }

    /**
     * Metodo que devuelve el rfc del veterinario
     * @return El rfc del veterinario a modificar
     */
    public String getRfc() {
        return rfc;
    }

    /**
     * Metodo que modifica el rfc del veterinario
     * @param rfc El rfc del veterinario
     */
    public void setRfc(String rfc) {
        this.rfc = rfc;
    }

    /**
     * Metodo que devuelve el nombre del veterinario
     * @return El nombre del veterinario a modificar
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Metodo que modifica el nombre del veterinario
     * @param nombre El nombre del veterinario
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Metodo que devuelve el apellido paterno del veterinario
     * @return El apellido paterno del veterinario a modificar
     */
    public String getApellidoPat() {
        return apellidoPat;
    }

    /**
     * Metodo que modifica el apellido paterno del veterinario
     * @param apellidoPat El apellido paterno del veterinario
     */
    public void setApellidoPat(String apellidoPat) {
        this.apellidoPat = apellidoPat;
    }

    /**
     * Metodo que devuelve el apellido materno del veterinario
     * @return El apellido materno del veterinario a modificar
     */
    public String getApellidoMat() {
        return apellidoMat;
    }

    /**
     * Metodo que modifica el apellido materno del veterinario
     * @param apellidoMat El apellido materno del veterinario
     */
    public void setApellidoMat(String apellidoMat) {
        this.apellidoMat = apellidoMat;
    }

    /**
     * Metodo que devuelve la calle de la direccion del veterinario
     * @return La calle de la direccion del veterinario a modificar
     */
    public String getCalle() {
        return calle;
    }

    /**
     * Metodo que modifica la calle de la direccion del veterinario
     * @param calle La calle de la direccion del veterinario
     */
    public void setCalle(String calle) {
        this.calle = calle;
    }

    /**
     * Metodo que devuelve el numero interior de la direccion del veterinario
     * @return El numero interior de la direccion del veterinario a modificar
     */
    public String getNumInt() {
        return numInt;
    }

    /**
     * Metodo que modifica el numero interior de la direccion del veterinario
     * @param numInt El numero interior de la direccion del veterinario
     */
    public void setNumInt(String numInt) {
        this.numInt = numInt;
    }

    /**
     * Metodo que devuelve el numero exterior de la direccion del veterinario
     * @return El numero exterior de la direccion del veterinario a modificar
     */
    public String getNumExt() {
        return numExt;
    }

    /**
     * Metodo que modifica el numero exterior de la direccion del veterinario
     * @param numExt El numero exterior de la direccion del veterinario
     */
    public void setNumExt(String numExt) {
        this.numExt = numExt;
    }

    /**
     * Metodo que devuelve la colonia de la direccion del veterinario
     * @return La colonia de la direccion del veterinario a modificar
     */
    public String getColonia() {
        return colonia;
    }

    /**
     * Metodo que modifica la colonia de la direccion del veterinario
     * @param colonia La colonia de la direccion del veterinario
     */
    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    /**
     * Metodo que devuelve el estado de la direccion del veterinario
     * @return El nestado de la direccion del veterinario a modificar
     */
    public String getEstado() {
        return estado;
    }

    /**
     * Metodo que modifica el estado de la direccion del veterinario
     * @param estado El estado de la direccion del veterinario a modificar
     */
    public void setEstado(String estado) {
        this.estado = estado;
    }

    /**
     * Metodo que devuelve el telefono del veterinario
     * @return El telefono del veterinario
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Metodo que modifica el telefono del veterinario
     * @param telefono El telefono del veterinario a modificar
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    /**
     * Metodo que devuelve la fecha de inicio el veterinario
     * @return La fecha de inicio el veterinario
     */
    public String getFechaInicio() {
        return fechaInicio;
    }

    /**
     * Metodo que modifica la fecha de inicio del veterinario
     * @param fechaInicio La fecha de inicio del veterinario a modificar
     */
    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    /**
     * Metodo que devuelve la fecha de nacimiento del veterinario
     * @return La fecha de nacimiento del veterinario
     */
    public String getFechaNac() {
        return fechaNac;
    }

    /**
     * Metodo que modifica la fecha de nacimiento del veterinario
     * @param fechaNac La fecha de nacimiento del veterinario a modificar
     */
    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    /**
     * Metodo que devuelve el correo del veterinario
     * @return El correo del veterinario
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * Metodo que modifica el correo del veterinario
     * @param correo El correo del veterinario a modificar
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * Metodo que devuelve el genero del veterinario
     * @return El genero del veterinario
     */
    public String getGenero() {
        return genero;
    }

    /**
     * Metodo que modifica el genero del veterinario
     * @param genero El genero del veterinario a modificar
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * Metodo que devuelve la especialidad del veterinario
     * @return La especialidad del veterinario
     */
    public String getEspecialidad() {
        return especialidad;
    }

    /**
     * Metodo que modifica la especialidad del veterinario
     * @param especialidad La especialidad del veterinario a modificar
     */
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    /**
     * Metodo que devuelve el salario del veterinario
     * @return El salario del veterinario
     */
    public String getSalario() {
        return salario;
    }

    /**
     * Metodo que modifica el salario del veterinario
     * @param salario El salario del veterinario a modificar
     */
    public void setSalario(String salario) {
        this.salario = salario;
    }

}



