/**
 * Clase que representa a un bioma del zoológico
 * @author Estrada García Luis Gerardo
 * @author Jiménez Hernández Allan  
 * @author Mancera Quiroz Javier Alejandro
 * @author Mora Hernández Dulce Julieta
 * @author Peña Nuñez Axel Yael
 * @version 10/09/2023
 */

 public class Bioma {
    private String tipoBioma;
    private String numJaulas;
    private String numCuidadores;
    private String numVeterinarios;
    private String numAnimales;
    private String servicios;
    private String idBioma;

    /**
     * Metodo constructor de la clase
     * @param tipoBioma El tipo del bioma
     * @param numJaulas El numero de jaulas
     * @param numCuidadores El numero de cuidadores
     * @param numVeterinarios El numero de veterinarios
     * @param numAnimales El numero de animales
     * @param servicios Los servicios que hay
     * @param idBioma El identificador de los biomas
     */
    public Bioma(String tipoBioma, String numJaulas, String numCuidadores, String numVeterinarios, String numAnimales, String servicios, String idBioma) {
        this.tipoBioma = tipoBioma;
        this.numJaulas = numJaulas;
        this.numCuidadores = numCuidadores;
        this.numVeterinarios = numVeterinarios;
        this.numAnimales = numAnimales;
        this.servicios = servicios;
        this.idBioma= idBioma;
    }
    
    /**
     * Metodo toString de la clase
     * @return Una cadena que representa la información del bioma.
     */
    @Override
    public String toString() {
        return this.tipoBioma + "," + this.numJaulas + "," + this.numCuidadores + "," + this.numVeterinarios +
        "," + this.numAnimales + "," + this.servicios + "," + this.idBioma;
    }

    /**
     * Metodo que devuelve el tipo de bioma
     * @return El tipo de bioma
     */
    public String getTipoBioma() {
        return tipoBioma;
    }

    /**
     * Metodo que modifica el tipo de bioma
     * @param tipoBioma El tipo de bioma a modificar
     */
    public void setTipoBioma(String tipoBioma){
        this.tipoBioma = tipoBioma;
    }

    /**
     * Metodo que devuelve el numero de jaulas
     * @return El numero de jaulas
     */
    public String getNumJaulas() {
        return numJaulas;
    }

    /**
     * Metodo que modifica el numero de jaulas
     * @param numJaulas El numero de jaulas a modificar
     */
    public void setNumJaulas(String numJaulas) {
        this.numJaulas = numJaulas;
    }

    /**
     * Metodo que devuelve el numero de cuidadores
     * @return El numero de cuidadores
     */
    public String getNumCuidadores() {
        return numCuidadores;
    }

    /**
     * Metodo que modifica el numero de cuidadores
     * @param numCuidadores El numero de cuidadores a modificar
     */
    public void setNumCuidadores(String numCuidadores) {
        this.numCuidadores = numCuidadores;
    }

    /**
     * Metodo que devuelve el numero de veterinarios
     * @return El numero de veterinarios
     */
    public String getNumVeterinarios() {
        return numVeterinarios;
    }

    /**
     * Metodo que modifica el numero de veterinarios
     * @param numVeterinarios El numero de veterinarios a modificar
     */
    public void setNumVeterinarios(String numVeterinarios) {
        this.numVeterinarios = numVeterinarios;
    }

    /**
     * Metodo que devuelve el numero de animales
     * @return El numero de animales
     */
    public String getNumAnimales() {
        return numAnimales;
    }

    /**
     * Metodo que modifica el numero de animales
     * @param numAnimales El numero de animales a modificar
     */
    public void setNumAnimales(String numAnimales) {
        this.numAnimales = numAnimales;
    }

    /**
     * Metodo que devuelve los servicios que hay
     * @return Los servicios que hay
     */
    public String getServicios() {
        return servicios;
    }

    /**
     * Metodo que modifica los servicios que hay
     * @param servicios Los servicios que hay 
     */
    public void setServicios(String servicios) {
        this.servicios = servicios;
    }

    /**
     * Metodo que devuelve el identificador del bioma
     * @return El identificador del bioma
     */
    public String getIdBioma() {
        return idBioma;
    }

    /**
     * Metodo que modifica el identificador del bioma
     * @param idBioma El identificador del bioma
     */
    public void setIdBioma(String idBioma) {
        this.idBioma = idBioma;
    }
}

