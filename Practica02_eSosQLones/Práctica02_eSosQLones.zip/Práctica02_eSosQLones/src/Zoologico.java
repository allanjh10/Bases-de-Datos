import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Clase que simula el zoologico, contiene el main y se ejecuta
 * @author Estrada García Luis Gerardo
 * @author Jiménez Hernández Allan  
 * @author Mancera Quiroz Javier Alejandro
 * @author Mora Hernández Dulce Julieta
 * @author Peña Nuñez Axel Yael
 * @version 1.0
 **/

public class Zoologico {

    private Animal[] animales=new Animal[9];
    private Veterinario[] veterinarios=new Veterinario[19];
    private Bioma[] biomas=new Bioma[6];

    private AnimalArchivo archivoAnimal= new AnimalArchivo();
    private VeterinarioArchivo archivoVeterinario= new VeterinarioArchivo();
    private BiomaArchivo archivoBioma= new BiomaArchivo();


    /**
     * Metodo carga que carga los datos a la simulacion de base de datos
     */
    public void carga(){
        try{
            animales=archivoAnimal.leeAnimales();
            veterinarios=archivoVeterinario.leeVeterinario();
            biomas=archivoBioma.leebiomas();
        }
        catch(Exception e){
            System.out.println("No se pudo cargar la base de datos");
        }
    }

    /**
     * Metodo que permite guardar un animal en el archivo
     */    
    public void guardaAnimal(){
        archivoAnimal.escribeAnimal(animales);
    }

    /**
     * Metodo que premite guardar un veterinario en el archivo
     */    
    public void guardaVeterinario(){
        archivoVeterinario.escribeVeterinario(veterinarios);
    }
   
    /**
     * Metodo que permite guardar un bioma en el archivo
     */
    public void guardaBioma(){
        archivoBioma.escribeBioma(biomas);
    }

    /**
     * Metodo que agrega un animal a un arreglo que contiene animales
     * @param animal El animal a agregar
     */    
    public void agregaAnimal(Animal animal){
        for(int i=0;i<animales.length;i++){
            if(animales[i]==null){
                animales[i]=animal;
                break;
            }
        }
    }

    /**
     * Metodo que agrega un veterinario a un arreglo que contiene veterinarios
     * @param veterinario El veterinario a agregar
     */
    public void agregaVeterinario(Veterinario veterinario){
        for(int i=0;i<veterinarios.length;i++){
            if(veterinarios[i]==null){
                veterinarios[i]=veterinario;
                break;
            }
        }
    }

    /**
     * Metodo que agrega un bioma a un arreglo que contiene biomas
     * @param bioma El bioma a agregar
     */
    public void agregaBioma(Bioma bioma){
        for(int i=0;i<biomas.length;i++){
            if(biomas[i]==null){
                biomas[i]=bioma;
                break;
            }
        }
    }

    /**
     * Metodo que elimina un animal del arreglo de animales
     * @param animal El animal a eliminar
     */    
    public void eliminaAnimal(Animal animal){
        for(int i=0;i<animales.length;i++){
            if(animales[i]==animal){
                animales[i]=null;
                break;
            }
        }
    }

    /**
     * Metodo que elimina un veterinario del arreglo de veterinarios
     * @param veterinario El veterinario a eliminar
     */    
    public void eliminaVeterinario(Veterinario veterinario){
        for(int i=0;i<veterinarios.length;i++){
            if(veterinarios[i]==veterinario){
                veterinarios[i]=null;
                break;
            }
        }


    }

    /**
     * Metodo que elimina un bioma del arreglo de biomas
     * @param bioma El bioma a eliminar
     */        
    public void eliminaBioma(Bioma bioma){
        for(int i=0;i<biomas.length;i++){
            if(biomas[i]==bioma){
                biomas[i]=null;
                break;
            }
        }
    }

    /**
     * Metodo auxiliar que verifica si las primeros 4 caracteres de una cadena son letras
     * @param st El string a verificar
     * @return true si las primeros 4 caracteres son letras, false en caso contrario
     */
    public boolean verificaRFCaux(String st){
        for(int i = 1; i <= 4; i++){
            if(Character.isLetter(st.charAt(i))){ 
                return true;
            }
        }
        return false;
    }

    /**
     * Metodo que verifica si una cadena cumple ser un RFC
     * @param st El string a verificar
     * @return true si es un RFC, false en caso contrario
     */
    public boolean verificaRFC(String st){
        if(st.length() == 13 && verificaRFCaux(st)){
            for(int i = 5; i < 11; i++){
                if(Character.isDigit(st.charAt(i))){  
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Metodo que verifica si una cadena dada es un telefono
     * @param st El string a verificar
     * @return true si es un telefono, false en caso contrario
     */
    public boolean verificaTelefono(String st){
        if(st.length() == 10){
            for(int i = 0; i < st.length(); i++){
                if(Character.isDigit(st.charAt(i))){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Metodo que verifica si una cadena dada es un tipo de bioma
     * @param st El string a verificar
     * @return true si es un tipo de bioma, false en caso contrario
     */
    public boolean verificaTipoBioma(String st){
        if("desierto".equals(st) || "pastizales".equals(st) || "franja costera".equals(st)
        || "tundra".equals(st) || "aviario".equals(st) || "bosque templado".equals(st) || 
        "bosque tropical".equals(st) ){
            return true;
        }
        return false;
    }

    /**
     * Metodo que verifica si es un servicio valido
     * @param st El string a verificar
     * @return true si en efecto es un servicio, false en caso contrario
     */
    public boolean verificaServicios(String st){
        if("banios".equals(st) || "tiendas".equals(st) || "comida".equals(st)){
            return true;
        }
        return false;
    }

    /**
     * Metodo que verifica si es una alimentacion valida
     * @param st El string a verificar
     * @return true si es una alimentacion valida, false en caso contrario
     */
    public boolean verificaAlimentacion(String st){
        if("herbivoro".equals(st) || "carnivoro".equals(st) || "omnivoro".equals(st) ){
            return true;
        }
        return false;
    }

    /**
     * Metodo que permite verificar si un string es de numeros
     * @param st El string a verificar
     * @return true si es un numero, false en caso contrario
     */
    public boolean verificaNumero(String st){
        for(int i = 0; i < st.length(); i++){
            if(Character.isDigit(st.charAt(i))){
                return true;
            }
        }
        return false;
    }

    /**
     * Metodo que permite verificar si un string es de letras
     * @param st El string a verificar
     * @return true si es de letras, false en caso contrario
     */
    public boolean verificaLetra(String st){
        for(int i = 0; i < st.length(); i++){
            if(Character.isLetter(st.charAt(i))){
                return true;
            }
        }
        return false;
    }

    /**
     * Metodo que contiene al menu de los animales
     * @param sn
     */    
    public void menuAnimales(Scanner sn) {
        System.out.println("Que desea hacer?");
        System.out.println("1. Agregar animal");
        System.out.println("2. Eliminar animal");
        System.out.println("3. Editar informacion de animal");
        System.out.println("4. Consultar animal");
        System.out.println("5. Regresar al menu principal");

        int opcion;
        while(true){
                       if(!sn.hasNextInt()){
                         System.out.println("\n" + "La opcion debe ser un NUMERO");
                         sn.nextLine();
                         continue;
                       }
                       opcion= sn.nextInt();
                       sn.nextLine(); 
//                       if(opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5){
                       if(opcion < 1 || opcion > 5){
                         System.out.println("\n" + "Elige un indice valido");
                         continue;
                       }
                       break;
                     }
    
        switch(opcion){
    
            case 1:
                System.out.println("Ingrese su nombre del animal");
                String nombre=sn.nextLine();
                System.out.println("Ingrese su especie del animal");
                String especie=sn.nextLine();            
                boolean validara = true;
                String peso = "";
                while(validara){
                    System.out.println("Ingrese el peso del animal");
                    peso = sn.nextLine();
                    boolean veri = verificaLetra(peso);
                        if(!veri){
                            validara = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                boolean validaraux = true;
                String altura = "";
                while(validaraux){
                    System.out.println("Ingrese la altura del animal");
                    altura = sn.nextLine();
                    boolean veri = verificaLetra(altura);
                        if(!veri){
                            validaraux = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                System.out.println("Ingrese su sexo del animal");
                String sexo=sn.nextLine();
                boolean validar = true;
                String numJaula = "";
//                String numJaula = sn.nextLine();
                while(validar){
                    System.out.println("Ingrese su numero de jaula del animal");
                    numJaula = sn.nextLine();
                    boolean veri = verificaNumero(numJaula);
                        if(veri){
                            validar = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                String alimentacion = "";
                boolean validar2 = true;
//                String alimentacion = sn.nextLine();
                while(validar2){
                    System.out.println("Ingrese el tipo de alimentacion(en minusculas y sin acentos)");
                    alimentacion = sn.nextLine();
                    boolean veri = verificaAlimentacion(alimentacion);
                        if(veri){
                            validar2 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un tipo de alimentacion valido(herbivoro, carnivoro, omnivoro), vuelve a intentarlo");
                        }
                }
                System.out.println("Ingrese el id para el animal");
                String indMed=sn.nextLine();
                while(verificaNoExiste(indMed)==true){
                    System.out.println("Ingrese el Id del animal (no debe repetirse)");
                    indMed=sn.nextLine();
                }
                Animal animal=new Animal(nombre,especie,peso,altura,sexo,numJaula,alimentacion,indMed);
                agregaAnimal(animal);
                guardaAnimal();
                break;
    
            //si esta registrado eliminar de la base de datos buscando su id
            case 2:
                System.out.println("Ingrese el ID del animal");
                String buscanimal = sn.nextLine();
                Animal buscaanimal = buscaAnimalPorId(buscanimal);
                if(buscaanimal != null){
                    eliminaAnimal(buscaanimal);
                    guardaAnimal();
                    System.out.println("Animal eliminado exitosamente :)");
                }
                else{
                    System.out.println("No se encontro el animal");
                }
                break;
            //editar informacion de animal
            case 3:
            System.out.println("Ingrese el ID del animal");
            String buscanimal2 = sn.nextLine();
            Animal buscaanimal2 = buscaAnimalPorId(buscanimal2);

            System.out.println("Ingrese el area que desea editar:"+ "\n1. nombre" + "\n2. especie" + "\n3. peso" + "\n4. altura" + "\n5. sexo" + "\n6. numero de jaula" + "\n7. alimentacion" + "\n8. indicaciones medicas");

            int opcion2;
            while(true){
                           if(!sn.hasNextInt()){
                             System.out.println("\n" + "La opcion debe ser un NUMERO");
                             sn.nextLine();
                             continue;
                           }
                           opcion2= sn.nextInt();
                           if(opcion2 < 1 || opcion2 > 8){
//                           if(opcion2 != 1 && opcion2 != 2 && opcion2 != 3 && opcion2 != 4 && opcion2 != 5 && opcion2 != 6 && opcion2 != 7 && opcion2 != 8){
                            System.out.println("\n" + "Elige un indice valido");
                             sn.nextLine();
                             continue;
                           }
                           break;
            }
            sn.nextLine();
            switch(opcion2){
                case 1:
                    System.out.println("Ingrese su nombre del animal");
                    String nombre2=sn.nextLine();
                    buscaanimal2.setNombre(nombre2);
                    guardaAnimal();
                    break;
                case 2:
                    System.out.println("Ingrese su especie del animal");
                    String especie2=sn.nextLine();
                    buscaanimal2.setEspecie(especie2);
                    guardaAnimal();
                    break;
                case 3:
                    System.out.println("Ingrese su peso del animal");
                    String peso2=sn.nextLine();
                    buscaanimal2.setPeso(peso2);
                    guardaAnimal();
                    break;
                case 4:
                    System.out.println("Ingrese su altura del animal");
                    String altura2=sn.nextLine();
                    buscaanimal2.setAltura(altura2);
                    guardaAnimal();
                    break;
                case 5:
                    System.out.println("Ingrese su sexo del animal");
                    String sexo2=sn.nextLine();
                    buscaanimal2.setSexo(sexo2);
                    guardaAnimal();
                    break;
                case 6:
                    System.out.println("Ingrese su numero de jaula del animal");
                    String numJaula2=sn.nextLine();
                    buscaanimal2.setNumJaula(numJaula2);
                    guardaAnimal();
                    break;
                case 7:
                    System.out.println("Ingrese su alimentacion del animal");
                    String alimentacion2=sn.nextLine();
                    buscaanimal2.setAlimentacion(alimentacion2);
                    guardaAnimal();
                    break;
                case 8:
                    System.out.println("Ingrese un Id para el animal");
                    String indMed2=sn.nextLine();
                    while(verificaNoExiste(indMed2)==true){
                        System.out.println("Ingrese el Id del animal (no debe repetirse)");
                        indMed2=sn.nextLine();
                    }
                    buscaanimal2.setAnimaId(indMed2);
                    guardaAnimal();
                    break;
            }
            break;
            //consultar animal
            case 4:
                System.out.println("Ingrese el ID del animal");
                String buscanimal3 = sn.nextLine();
                Animal buscaanimal3 = buscaAnimalPorId(buscanimal3);
                if(buscaanimal3 != null){
                    imprimeAnimal(buscaanimal3);
                }
                else{
                    System.out.println("No se encontro el animal");
                }
                break;
        }
    }
    

    /**
     * Metodo que veridica si un id ya existe
     * @param idMed2 el id
     * @return 
     */
    private boolean verificaNoExiste(String idMed2) {
        if (animales[0] == null) {
            return false;
        }
        for (int i = 0; i < animales.length; i++) {
            if (animales[i] != null && animales[i].getAnimaId().equals(idMed2)) {
                return true; 
            }
        }
        return false;
    }
    

    /**
     * Metodo que imprime al animal
     * @param buscaanimal3 El animal buscado
     */    
    private void imprimeAnimal(Animal buscaanimal3) {
        System.out.println("Nombre: "+buscaanimal3.getNombre());
        System.out.println("Especie: "+buscaanimal3.getEspecie());
        System.out.println("Peso: "+buscaanimal3.getPeso());
        System.out.println("Altura: "+buscaanimal3.getAltura());
        System.out.println("Sexo: "+buscaanimal3.getSexo());
        System.out.println("Numero de jaula: "+buscaanimal3.getNumJaula());
        System.out.println("Alimentacion: "+buscaanimal3.getAlimentacion());
        System.out.println("Indicaciones medicas: "+buscaanimal3.getAnimaId());
    }

    /**
     * Metodo que busca un animal por id
     * @param buscanimal El animal a buscar
     * @return El animal buscado, en caso de no existir, devuelve null
     */    
    private Animal buscaAnimalPorId(String buscanimal) {
        for(int i = 0; i < animales.length; i++) {
            if (animales[i] != null && animales[i].getAnimaId().equals(buscanimal)) {
                return animales[i];
            }
        }
        return null;
    }

    /**
     * Metodo que da el menu de los veterinarios
     * @param sn
     */    
    public void menuVeterinarios(Scanner sn){
        System.out.println("Que desea hacer?");
        System.out.println("1. Agregar veterinario");
        System.out.println("2. Eliminar veterinario");
        System.out.println("3. Editar informacion de veterinario");
        System.out.println("4. Consultar veterinario");
        System.out.println("5. Regresar al menu principal");
        int opcion;
        while(true){
                       if(!sn.hasNextInt()){
                         System.out.println("\n" + "La opcion debe ser un NUMERO");
                         sn.nextLine();
                         continue;
                       }
                       opcion= sn.nextInt();
                       if(opcion < 1 || opcion > 5){
//                       if(opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5){
                         System.out.println("\n" + "Elige un indice valido");
                         sn.nextLine();
                         continue;
                       }
                       break;
                     }

        sn.nextLine();

        switch(opcion){
            case 1:
                boolean validar = true;
                String rfc = "";
                while(validar){
                    System.out.println("Ingrese su rfc del veterinario");
                    rfc = sn.nextLine();
                    boolean veri = verificaRFC(rfc);
                            if(veri){
                                validar = false;
                                break;
                            }else{
                                System.out.println("No ingresaste un RFC, vuelve a intentarlo");
                            }
                }
                System.out.println("Ingrese su nombre del veterinario");
                String nombre=sn.nextLine();
                System.out.println("Ingrese su apellido paterno del veterinario");
                String apellidoPat=sn.nextLine();
                System.out.println("Ingrese su apellido materno del veterinario");
                String apellidoMat=sn.nextLine();
                System.out.println("Ingrese su calle del veterinario");
                String calle=sn.nextLine();
                boolean validarnum1 = true;
                String numInt = "";
                while(validarnum1){
                    System.out.println("Ingrese el numero interior");
                    numInt = sn.nextLine();
                    boolean veri = verificaNumero(numInt);
                        if(veri){
                            validarnum1 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                boolean validarnum2 = true;
                String numExt = "";
                while(validarnum2){
                    System.out.println("Ingrese el numero exterior");
                    numExt = sn.nextLine();
                    boolean veri = verificaNumero(numExt);
                        if(veri){
                            validarnum2 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                System.out.println("Ingrese su colonia del veterinario");
                String colonia=sn.nextLine();
                System.out.println("Ingrese el Estado del veterinario");
                String estado=sn.nextLine();
                boolean validar2 = true;
                String telefono = "";
                while(validar2){
                    System.out.println("Ingrese el telefono del veterinario(10 digitos sin espacios)");
                    telefono = sn.nextLine();
                    boolean veri = verificaTelefono(telefono);
                        if(veri){
                            validar2 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un telefono, vuelve a intentarlo");
                        }
                }
                System.out.println("Ingrese la Fecha de Ingreso del veterinario");
                String fechaInicio=sn.nextLine();
                System.out.println("Ingrese la Fecha de Nacimiento del veterinario");
                String fechaNac=sn.nextLine();
                System.out.println("Ingrese el correo del veterinario");
                String correo=sn.nextLine();
                System.out.println("Ingrese el genero del veterinario");
                String genero=sn.nextLine();
                System.out.println("Ingrese la especialidad del veterinario");
                String especialidad=sn.nextLine();
                System.out.println("Ingrese el salario del veterinario");
                String salario=sn.nextLine();
                Veterinario veterinario=new Veterinario(rfc,nombre,apellidoPat,apellidoMat,calle,numInt,numExt,colonia,estado,telefono,fechaInicio,fechaNac,correo,genero,especialidad,salario);
                agregaVeterinario(veterinario);
                guardaVeterinario();
                break;

       //si esta registrado eliminar de la base de datos buscando su rfc
            case 2:
                System.out.println("Ingrese su rfc del veterinario");
                String buscarfc = sn.nextLine();
                Veterinario buscaveterinario = buscaVeterinarioPorRfc(buscarfc);
                if(buscaveterinario != null){
                    eliminaVeterinario(buscaveterinario);
                }
                else{
                    System.out.println("No se encontro el veterinario");
                }
                break;
            
        //editar informacion de veterinario
        
            case 3:
            System.out.println("Ingrese su rfc del veterinario");
            String buscarfc2 = sn.nextLine();
            Veterinario buscaveterinario2 = buscaVeterinarioPorRfc(buscarfc2);

            System.out.println("Ingrese el area que desea editar:"+ "\n1. rfc" + "\n2. nombre" + "\n3. apellido paterno" + "\n4. apellido materno" + "\n5. calle" + "\n6. numero interior" + "\n7. numero exterior" + "\n8. colonia" + "\n9. estado" + "\n10. telefono" + "\n11. fecha de inicio" + "\n12. fecha de nacimiento" + "\n13. correo" + "\n14. genero" + "\n15. especialidad" + "\n16. salario");

            int opcion2;
            while(true){
                           if(!sn.hasNextInt()){
                             System.out.println("\n" + "La opcion debe ser un NUMERO");
                             sn.nextLine();
                             continue;
                           }
                           opcion2= sn.nextInt();
//                           if(opcion2 != 1 && opcion2 != 2 && opcion2 != 3 && opcion2 != 4 && opcion2 != 5 && opcion2 != 6 && opcion2 != 7 && opcion2 != 8 && opcion2 != 9 && opcion2 != 10 && opcion2 != 11 && opcion2 != 12 && opcion2 != 13 && opcion2 != 14 && opcion2 != 15 && opcion2 != 16){
                           if(opcion2 < 1 || opcion2 > 16){
                             System.out.println("\n" + "Elige un indice valido");
                             sn.nextLine();
                             continue;
                           }
                           break;
            }
            sn.nextLine();
            switch(opcion2){
                case 1:
                    System.out.println("Ingrese su rfc del veterinario");
                    String rfc2=sn.nextLine();
                    buscaveterinario2.setRfc(rfc2);
                    guardaVeterinario();
                    break;
                case 2:
                    System.out.println("Ingrese su nombre del veterinario");
                    String nombre2=sn.nextLine();
                    buscaveterinario2.setNombre(nombre2);
                    guardaVeterinario();
                    break;
                case 3:
                    System.out.println("Ingrese su apellido paterno del veterinario");
                    String apellidoPat2=sn.nextLine();
                    buscaveterinario2.setApellidoPat(apellidoPat2);
                    guardaVeterinario();
                    break;
                case 4:
                    System.out.println("Ingrese su apellido materno del veterinario");
                    String apellidoMat2=sn.nextLine();
                    buscaveterinario2.setApellidoMat(apellidoMat2);
                    guardaVeterinario();
                    break;
                case 5:
                    System.out.println("Ingrese su calle del veterinario");
                    String calle2=sn.nextLine();
                    buscaveterinario2.setCalle(calle2);
                    guardaVeterinario();
                    break;
                case 6:
                    System.out.println("Ingrese su numero interior del veterinario");
                    String numInt2=sn.nextLine();
                    buscaveterinario2.setNumInt(numInt2);
                    guardaVeterinario();
                    break;
                case 7:
                    System.out.println("Ingrese su numero exterior del veterinario");
                    String numExt2=sn.nextLine();
                    buscaveterinario2.setNumExt(numExt2);
                    guardaVeterinario();
                    break;
                case 8:
                    System.out.println("Ingrese su colonia del veterinario");
                    String colonia2=sn.nextLine();
                    buscaveterinario2.setColonia(colonia2);
                    guardaVeterinario();
                    break;
                case 9:
                    System.out.println("Ingrese el Estado del veterinario");
                    String estado2=sn.nextLine();
                    buscaveterinario2.setEstado(estado2);
                    guardaVeterinario();
                    break;
                case 10:
                    System.out.println("Ingrese el telefono del veterinario");
                    String telefono2=sn.nextLine();
                    buscaveterinario2.setTelefono(telefono2);
                    guardaVeterinario();
                    break;
                case 11:
                    System.out.println("Ingrese la Fecha de Ingreso del veterinario");
                    String fechaInicio2=sn.nextLine();
                    buscaveterinario2.setFechaInicio(fechaInicio2);
                    guardaVeterinario();
                    break;
                case 12:

                    System.out.println("Ingrese la Fecha de Nacimiento del veterinario");
                    String fechaNac2=sn.nextLine();
                    buscaveterinario2.setFechaNac(fechaNac2);
                    guardaVeterinario();
                    break;
                case 13:
                    System.out.println("Ingrese el correo del veterinario");
                    String correo2=sn.nextLine();
                    buscaveterinario2.setCorreo(correo2);
                    guardaVeterinario();
                    break;
                case 14:
                    System.out.println("Ingrese el genero del veterinario");
                    String genero2=sn.nextLine();
                    buscaveterinario2.setGenero(genero2);
                    guardaVeterinario();
                    break;
                case 15:
                    System.out.println("Ingrese la especialidad del veterinario");
                    String especialidad2=sn.nextLine();
                    buscaveterinario2.setEspecialidad(especialidad2);
                    guardaVeterinario();
                    break;
                case 16:
                    System.out.println("Ingrese el salario del veterinario");
                    String salario2=sn.nextLine();
                    buscaveterinario2.setSalario(salario2);
                    guardaVeterinario();
                    break;
        }
        break;

    //consultar veterinario
    case 4:
          System.out.println("Ingrese su rfc del veterinario");
          String buscarfc3 = sn.nextLine();
          //String buscarfc3 = sn.nextLine();
          Veterinario buscaveterinario3 = buscaVeterinarioPorRfc(buscarfc3);
          if(buscaveterinario3 != null){
              imprimeVeterinario(buscaveterinario3);
          }
          else{
              System.out.println("No se encontro el veterinario");
          }
          break;

        //regresar al menu principal
    case 5:
        break;
        }


      
    }

    /**
     * Metodo que imprime el veterinario
     * @param buscaveterinario3 El veterinario a imprimir
     */
    private void imprimeVeterinario(Veterinario buscaveterinario3) {
        System.out.println("RFC: "+buscaveterinario3.getRfc());
        System.out.println("Nombre: "+buscaveterinario3.getNombre());
        System.out.println("Apellido Paterno: "+buscaveterinario3.getApellidoPat());
        System.out.println("Apellido Materno: "+buscaveterinario3.getApellidoMat());
        System.out.println("Calle: "+buscaveterinario3.getCalle());
        System.out.println("Numero Interior: "+buscaveterinario3.getNumInt());
        System.out.println("Numero Exterior: "+buscaveterinario3.getNumExt());
        System.out.println("Colonia: "+buscaveterinario3.getColonia());
        System.out.println("Estado: "+buscaveterinario3.getEstado());
        System.out.println("Telefono: "+buscaveterinario3.getTelefono());
        System.out.println("Fecha de Ingreso: "+buscaveterinario3.getFechaInicio());
        System.out.println("Fecha de Nacimiento: "+buscaveterinario3.getFechaNac());
        System.out.println("Correo: "+buscaveterinario3.getCorreo());
        System.out.println("Genero: "+buscaveterinario3.getGenero());
        System.out.println("Especialidad: "+buscaveterinario3.getEspecialidad());
        System.out.println("Salario: "+buscaveterinario3.getSalario());
    }

    /**
     * Metodo que busca a un veterinario por Rfc
     * @param buscarfc el rfc a buscar
     * @return el veterinario asociado a ese rfc, en caso de no encontrarlo devuelve null
     */    
    private Veterinario buscaVeterinarioPorRfc(String buscarfc) {
        for(int i = 0; i < veterinarios.length; i++) {
            if (veterinarios[i] != null && veterinarios[i].getRfc().equals(buscarfc)) {
                return veterinarios[i];
            }
        }
        return null;
    }


    /**
     * Metodo que muestra el menu de biomas
     * @param sn
     */
    public void menuBiomas(Scanner sn) {
        System.out.println("Que desea hacer?");
        System.out.println("1. Agregar bioma");
        System.out.println("2. Eliminar bioma");
        System.out.println("3. Editar informacion de bioma");
        System.out.println("4. Consultar bioma");
        System.out.println("5. Regresar al menu principal");

        int opcion;
        while(true){
                       if(!sn.hasNextInt()){
                         System.out.println("\n" + "La opcion debe ser un NUMERO");
                         sn.nextLine();
                         continue;
                       }
                       opcion= sn.nextInt();
                       sn.nextLine(); // Consumir el salto de línea
//                       if(opcion != 1 && opcion != 2 && opcion != 3 && opcion != 4 && opcion != 5){
                       if(opcion < 1 || opcion > 5){
                         System.out.println("\n" + "Elige un indice valido");
                         continue;
                       }
                       break;
                     }

        switch(opcion){
            //agregar bioma
            case 1:
                String tipoBioma = "";
                boolean validarTB = true;
                while(validarTB){
                    System.out.println("Ingrese el tipo de bioma(en minusculas)");
                    tipoBioma = sn.nextLine();
                    boolean veri = verificaTipoBioma(tipoBioma);
                        if(veri){
                            validarTB = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un tipo de bioma correcto(desierto, pastizales, franja costera, tundra, aviario, bosque templado, bosque tropical), vuelve a intentarlo");
                        }
                }
                boolean validar = true;
                String numJaulas = "";
                while(validar){
                    System.out.println("Ingrese el numero de jaulas");
                    numJaulas = sn.nextLine();
                    boolean veri = verificaNumero(numJaulas);
                        if(veri){
                            validar = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }
                boolean validar2 = true;
                String numCuidadores = "";
                while(validar2){
                    System.out.println("Ingrese el numero de cuidadores");
                    numCuidadores = sn.nextLine();
                    boolean veri = verificaNumero(numCuidadores);
                        if(veri){
                            validar2 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }  
                boolean validar3 = true;
                String numVeterinarios = "";
                while(validar3){
                    System.out.println("Ingrese el numero de veterinarios");
                    numVeterinarios = sn.nextLine();
                    boolean veri = verificaNumero(numVeterinarios);
                        if(veri){
                            validar3 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }  
                boolean validar4 = true;
                String numAnimales = "";
                while(validar4){
                    System.out.println("Ingrese el numero de animales");
                    numAnimales = sn.nextLine();
                    boolean veri = verificaNumero(numAnimales);
                        if(veri){
                            validar4 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un numero, vuelve a intentarlo");
                        }
                }  
                boolean validar5 = true;
                String servicios = "";
                while(validar5){
                    System.out.println("Ingrese los servicios(con minusculas)");
                    servicios = sn.nextLine();
                    boolean veri = verificaServicios(servicios);
                        if(veri){
                            validar5 = false;
                            break;
                        }else{
                            System.out.println("No ingresaste un servicio valido(banios, comida, tiendas), vuelve a intentarlo");
                        }
                }  
                System.out.println("Ingrese un Id para el bioma");
                String idBioma=sn.nextLine();
                while(verificaNoExiste(idBioma)==true){
                    System.out.println("Ingrese el Id del bioma (no debe repetirse)");
                    idBioma=sn.nextLine();
                }

                Bioma bioma=new Bioma(tipoBioma,numJaulas,numCuidadores,numVeterinarios,numAnimales,servicios, idBioma);
                agregaBioma(bioma);
                guardaBioma();
                break;
            //si esta registrado eliminar de la base de datos buscando por id de bioma
            case 2:
                System.out.println("Ingrese el id de bioma");
                String buscatipoBioma = sn.nextLine();
                Bioma buscatipoBioma1 = buscaBiomaPorId(buscatipoBioma);
                if(buscatipoBioma1 != null){
                    eliminaBioma(buscatipoBioma1);
                    guardaBioma();
                    System.out.println("Bioma eliminado exitosamente :)");
                }
                else{
                    System.out.println("No se encontro el bioma");
                }
                break;
            
            //editar informacion de bioma
            case 3:
            System.out.println("Ingrese el id de bioma");
            String buscatipoBioma2 = sn.nextLine();
            Bioma buscatipoBioma3 = buscaBiomaPorId(buscatipoBioma2);


            System.out.println("Ingrese el area que desea editar:"+ "\n1. tipo de bioma" + "\n2. numero de jaulas" + "\n3. numero de cuidadores" + "\n4. numero de veterinarios" + "\n5. numero de animales" + "\n6. servicios" + "\n7. Id del bioma");
            int opcion2;
            while(true){
                        if(!sn.hasNextInt()){
                             System.out.println("\n" + "La opcion debe ser un NUMERO");
                             sn.nextLine();
                             continue;
                           }
                           opcion2= sn.nextInt();
                           sn.nextLine();
                           //if(opcion2 != 1 && opcion2 != 2 && opcion2 != 3 && opcion2 != 4 && opcion2 != 5 && opcion2 != 6 && opcion2 != 7){
                            if(opcion2 < 1 || opcion2 > 16){
                             System.out.println("\n" + "Elige un indice valido");
                             sn.nextLine();
                             continue;
                           }
                           break;
            }

            switch(opcion2){
                case 1:
                    System.out.println("Ingrese el tipo de bioma");
                    String tipoBioma2=sn.nextLine();
                    buscatipoBioma3.setTipoBioma(tipoBioma2);
                    guardaBioma();
                    break;
                case 2:
                    System.out.println("Ingrese el numero de jaulas");
                    String numJaulas2=sn.nextLine();
                    buscatipoBioma3.setNumJaulas(numJaulas2);
                    guardaBioma();
                    break;
                case 3:
                    System.out.println("Ingrese el numero de cuidadores");
                    String numCuidadores2=sn.nextLine();
                    buscatipoBioma3.setNumCuidadores(numCuidadores2);
                    guardaBioma();
                    break;
                case 4:
                    System.out.println("Ingrese el numero de veterinarios");
                    String numVeterinarios2=sn.nextLine();
                    buscatipoBioma3.setNumVeterinarios(numVeterinarios2);
                    guardaBioma();
                    break;
                case 5:
                    System.out.println("Ingrese el numero de animales");
                    String numAnimales2=sn.nextLine();
                    buscatipoBioma3.setNumAnimales(numAnimales2);
                    guardaBioma();
                    break;
                case 6:
                    System.out.println("Ingrese los servicios");
                    String servicios2=sn.nextLine();
                    buscatipoBioma3.setServicios(servicios2);
                    guardaBioma();
                    break;
                case 7:
                    System.out.println("Ingrese un Id para el bioma");
                    String idBioma2=sn.nextLine();
                    while(verificaNoExiste(idBioma2)==true){
                        System.out.println("Ingrese el Id del bioma (no debe repetirse)");
                        idBioma2=sn.nextLine();
                    }
                    buscatipoBioma3.setIdBioma(idBioma2);
                    guardaBioma();
                    break;
            }
            break;

            //consultar bioma
            case 4:
                System.out.println("Ingrese el id de bioma");
                String buscatipoBioma4 = sn.nextLine();
                Bioma buscatipoBioma5 = buscaBiomaPorId(buscatipoBioma4);
                if(buscatipoBioma5 != null){
                    imprimeBioma(buscatipoBioma5);
                }
                else{
                    System.out.println("No se encontro el bioma");
                }
                break;
            //regresar al menu principal
            case 5:
                break;
      

    }
}

 
    /**
     * Metodo que imprime los biomas
     * @param buscatipoBioma5 El bioma a imprimir
     */
    private void imprimeBioma(Bioma buscatipoBioma5) {
        System.out.println("Tipo de bioma: "+buscatipoBioma5.getTipoBioma());
        System.out.println("Numero de jaulas: "+buscatipoBioma5.getNumJaulas());
        System.out.println("Numero de cuidadores: "+buscatipoBioma5.getNumCuidadores());
        System.out.println("Numero de veterinarios: "+buscatipoBioma5.getNumVeterinarios());
        System.out.println("Numero de animales: "+buscatipoBioma5.getNumAnimales());
        System.out.println("Servicios: "+buscatipoBioma5.getServicios());
        System.out.println("Id del bioma: "+buscatipoBioma5.getIdBioma());
    }

    /**
     * Metodo que busca bioma por id
     * @param buscatipoBioma4 El bioma a buscar
     * @return si lo encuentra, el bioma buscado. En caso contrario, null
     */    
    private Bioma buscaBiomaPorId(String buscatipoBioma4) {
        for(int i = 0; i < biomas.length; i++) {
            if (biomas[i] != null && biomas[i].getIdBioma().equals(buscatipoBioma4)) {
                return biomas[i];
            }
        }
        return null;
    }

    /**
     * Metodo main, donde se da la bienvenida y se comienza la ejecucion del programa
     * @param args Los argumentos del main
     */
    public static void main(String[] args) { 
        Zoologico zoo = new Zoologico();
        Scanner sn = new Scanner(System.in);
        zoo.carga();
        boolean salir = false;
        int opcion;
 
        System.out.println("---------- ZOOLOGICO DE HUITZILTEPEC ----------");
        while (!salir) {
            System.out.println("1. VETERINARIOS");
            System.out.println("2. ANIMALES");
            System.out.println("3. BIOMAS");
            System.out.println("4. Salir");
 
            try {
                System.out.println("¿Que desea hacer? (Ingrese el numero de la accion a realizar)");
                opcion = sn.nextInt();
 
                switch (opcion) {
                    case 1:
                        System.out.println("------ VETERINARIOS ------");
                        zoo.menuVeterinarios(sn);
                        zoo.guardaVeterinario();
                        break;
                    case 2:
                        System.out.println("------ ANIMALES ------");
                        zoo.menuAnimales(sn);
                        zoo.guardaAnimal();
                     break;
                    case 3:
                        System.out.println("------ BIOMAS ------");
                        zoo.menuBiomas(sn);
                        zoo.guardaBioma();

                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        System.out.println("Debes insertar un numero entre 1 y 4");
                }
            }    catch (InputMismatchException e) {
                System.out.println("Debes insertar un numero. Vuelve a intentarlo");
                sn.nextLine();  // Consumir todo lo que queda en la línea
            }
        
            
        }

    }


}

